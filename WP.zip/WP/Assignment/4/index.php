<html>
<head>
<style>
#menu
{
width: 500px;
height: 500px;
float: left;
background-color: white;
padding: 20px;
margin: 0px;
}

</style>
  
</head>
  
<body >
  
<div id="main"> 
<h1 style="color: black;">ADDRESS BOOK</h1> 
</div>
<div id="menu" id="center">
<ul style="list-style-type:none;">
<li><hr>MENU</li>
<li><hr></li>
<li><a href="add.html" style="text-decoration: none;" >ADD PROFILE</a></li>
<li><a href="delete.html"style="text-decoration: none;">DELETE PROFILE</a></li>
<li><a href="update.html"style="text-decoration: none;">UPDATE PROFILE</a></li>
<li><a href="search.html"style="text-decoration: none;">SEARCH PROFILE</a></li>
  
</ul>
  
</div>
  
</body>
  
  
</html>
