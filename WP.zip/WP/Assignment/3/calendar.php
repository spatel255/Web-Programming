<!DOCTYPE html>
<html>
  <link rel="stylesheet" type="text/css" href="calendar.css" />
  <head>
    <title>Part 2</title>
  </head>
  <body>
  <center>
    <?php
               date_default_timezone_set('America/New_York');
               $hours_to_show = 11;
           if(isset($_POST['submit'])){
               $hours_to_show = $_POST["hours_to_show"] - 1;
           }
               $timeStamp = time();
               $todayDate = date("D, F j, Y", $timeStamp);
               $currentTime = date("g:i a",$timeStamp);
               $todayDay = date("l", $timeStamp);
               function get_hour_string($timeStamp){
                   $hour = date("g", $timeStamp);
                   $am_or_pm = date("a", $timeStamp);
                   return "$hour:00 $am_or_pm";
               }

           ?>
      <div class="container">
        <h1>  <center>

                   <?php
                       echo "<br><b>ASSIGNMENT 3 PART 2</b><br>";
                       echo "<br><b>WEEKDAY:</b>: $todayDay";
                       echo "<br><b>CURRENT DATE:</b>: $todayDate";
                       echo "<br><b>TIME:</b> $currentTime <br>";
                   ?>
               <form method="POST">
                   Hours : <input type="number" name="hours_to_show">
                   <input type="submit" value="submit" name = "submit">
               </form>
               </h1>  </center>
        <table id="event_table">
          <tr>
            <th class='hr_td'></th>
            <th class='table_header'></th>
            <th class='table_header'></th>
            <th class='table_header'></th>
          </tr>
          <tr>
            <br> </tr>
          <?php
           for ($i = 0; $i <= $hours_to_show; $i++) {
               $hours = get_hour_string($timeStamp + $i * 60 * 60);
               if ($i % 2 == 0) {
                   echo "<tr class='odd_row'> ";
                   echo "<td class='hr_td'>
                               <b>$hours</b>
                       </td>
                       <td> </td>
                       <td> </td>
                       <td> </td> ";
                   echo "</tr> ";

               }
               if ($i % 2 != 0) {

                   echo "<tr class='even_row'> ";
                   echo "<td class='hr_td'>
                               <b>$hours</b>
                       </td>
                       <td> </td>
                       <td> </td>
                       <td> </td> ";
                   echo "</tr> ";
               }
           }
           ?>
        </table>
      </div>
 </center>
  </body>

</html>
