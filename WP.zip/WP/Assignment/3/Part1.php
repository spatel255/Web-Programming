<html>

<head>
	<title>part1</title>
</head>
<style>
.select {
	padding: 10px;
	margin: 10px;
	border: 3px solid black;
	box-shadow: 5px 5px 5px #ccc;
}

.select:hover {
	box-shadow: 0px 0px 0px white;
}

.btn {
	background-color: white;
	color: black;
	cursor: none;
}
</style>

<body>
<h1>PHP processor Assignment</h1>
	<form method="post" action="<?php echo htmlentities($_SERVER['PHP_SELF']); ?>">
		<h2>Select the Font Color</h2>
		<select name="color" class="select" required>
			<option value=''>Select Color of font</option>
			<option value='white'>White</option>
			<option value='#C5FF00'>Light green</option>
			<option value='#D6EAF8'>Sky Blue</option>
			<option value='#FFF333'>Yellow</option>
		</select>
		<br/>
		<h2>Select the Background Color</h2>
		<select name="bgcolor" class="select" required>
			<option value=''>Select BackgroundColor</option>
			<option value='#D35400'>Brown</option>
			<option value='#FF333F'>Red</option>
			<option value='#333FFF'>Blue</option>
			<option value='black'>Black</option>
		</select>
		<br/>
		<h2>Select the Font:</h2>
		<select name="font" class="select" required>
			<option value=''>Select Font</option>
			<option value="times new roman">Times New Roman</option>
			<option value='Forte'>Forte</option>
			<option value='Arial'>Arial</option>
		</select>
		<br/>
		<h2>Input:</h2>
		<textarea class="select" cols="20" rows="10" name="text" required></textarea>
		<br/>
		<input class="select btn" type="submit" name="s"> </form>
</body>
<?php

if(isset($_POST['s']))

{

$color= $_POST['color'];

$bgcolor= $_POST['bgcolor'];

$font= $_POST['font'];

$text=$_POST['text'];

echo"Output:";
echo "<div style='width:*; color:$color; background-color:$bgcolor;font-family:$font; font-size:20px; border: 3px solid gray;'>

".$text."

</div>

";

}

?>

</html>
