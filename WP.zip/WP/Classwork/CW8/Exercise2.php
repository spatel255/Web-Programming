<html>
  <head>
    <title>PHP Test</title>
</head>
<body>
<?php	
for ($i=1; $i<=5; $i++)	
{	 
for($j=1;$j<=$i;$j++)	  
{	  	
echo " * ";	 
}	  	
echo "<br/>";   	
}  
?>
</body>
</html>