var i,j;
var n=prompt("Enter a number of rows ");
for(var i=1;i<=n;i++)
 {
  for(var j=1;j<=i;j++)
   {
    document.write(' $ ');
document.write("  ");
   }
   document.write("<br /><br />");
 }
