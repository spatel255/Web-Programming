CREATE DATABASE IF NOT EXISTS foodie;
CREATE TABLE user(
user_name varchar(255) NOT NULL,
user_email varchar(255) NOT NULL,
user_message varchar(255) NOT NULL,
)
